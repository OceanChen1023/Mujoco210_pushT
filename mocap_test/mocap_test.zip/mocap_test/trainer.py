import gymnasium as gym
from stable_baselines3 import PPO
from pushT_env import PushEnv
from stable_baselines3.common.vec_env import DummyVecEnv


def main():
    # 創建自定義環境
    env = PushEnv("./UR5_pole.xml")
    Vec_env = DummyVecEnv([lambda:env])

    # 創建 PPO 模型
    model = PPO("MlpPolicy", 
                Vec_env, 
                verbose=1,
                learning_rate=1e-3,
                n_steps=4096,
                batch_size=32,
                n_epochs=10,
                gamma=0.99,
                gae_lambda=0.95,
                clip_range=0.2,
                ent_coef=0.0,
                tensorboard_log="./tensorboard_logs/")
    
    # 訓練模型
    model.learn(total_timesteps=1000000000)
    
    # 保存模型
    model.save("models/ppo_custom_push")
    
    # 測試模型
    obs = Vec_env.reset()
    for _ in range(1000):
        action, _states = model.predict(obs)
        obs, reward, collision, info = Vec_env.step(action)

        obs = Vec_env.reset()
        Vec_env.render()
        if collision:
            obs = Vec_env.reset()

if __name__ == "__main__":
    main()
