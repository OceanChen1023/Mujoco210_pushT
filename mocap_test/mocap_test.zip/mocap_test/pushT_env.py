import gym
import numpy as np
from mujoco_py import load_model_from_path, MjSim, MjViewer
import glfw


class PushEnv(gym.Env):

    def __init__(self,model_xml_path):
        super().__init__()
        # Load MuJoCo model
        self.model = load_model_from_path(model_xml_path)
        self.sim = MjSim(self.model)
        self.viewer = MjViewer(self.sim)
        render=True

        # 是否顯示 MuJoCo Viewer
        self.render_enabled = render
        if self.render_enabled:
            glfw.init()  # 確保 glfw 有被初始化
            self.viewer = MjViewer(self.sim)
        else:
            self.viewer = None
        # Define action and observation space
        self.action_space = gym.spaces.Box(low=-0.3, high=0.3, shape=(3,), dtype=np.float32)
        self.observation_space = gym.spaces.Box(low=-np.inf, high=np.inf, shape=(6,), dtype=np.float32)   #observation space={ee_x,ee_y,ee_z}
        self.ee_init_pos =self._get_ee_pos() #np.array(3, dtype=np.float32)
        self._set_robot_pose()
        self.block_init_pos = self._get_block_init_pos() #np.array(3,dtype=np.float32)
        print("ee init pos: ",self.ee_init_pos)
        self.phase=0


    def reset(self):
        self.sim.reset()
        self.phase=0
        # 重置末端位置
        #init_pos = np.array([0.5, 0.2, 1.8])
        #block_init_pos=np.array([0.6, 0.0, 1.1])
        
        #self._set_ee_pos(self.ee_init_pos)
        self._set_robot_pose()
        self._set_block_pos(self.block_init_pos)

        if self.render_enabled and self.viewer is not None:
            self.render()
        return self._get_obs()

    def _set_robot_pose(self):
        print("set robot pose")
        target_positions = [0.028, -0.66, 1.984, 0.297, -0.008, 0.0234]
        for i, joint_name in enumerate(["shoulder_pan_joint", "shoulder_lift_joint", "elbow_joint", "wrist_1_joint", "wrist_2_joint", "wrist_3_joint"]):
            joint_id = self.sim.model.joint_name2id(joint_name)  # 獲取關節 ID
            dof_index = self.sim.model.jnt_qposadr[joint_id]    # 獲取 DOF 在 qpos 中的索引

            self.sim.data.qpos[dof_index] = target_positions[i]
        # # 設置目標位置
        self.sim.forward()
        #return self.sim.data.qpos[dof_index] 

    def _get_ee_pos(self):
        return self.sim.data.get_mocap_pos("mocap")

    def _set_ee_pos(self, new_pos):
        self.sim.data.set_mocap_pos("mocap", new_pos)
        self.sim.forward()
    
    def _get_ee_init_pos(self):
        ee_id=self.model.body_name2id("Pole")
        return self.model.body_pos[ee_id]
  
    def _get_block_pos(self):
        temp_b_ID = self.sim.model.body_name2id("T_block")
        pos=self.sim.data.body_xpos[temp_b_ID]
        #print("block_pos=",pos)
        return pos

    def _set_block_pos(self,new_pos):
        temp_b_ID = self.sim.model.body_name2id("T_block")
        self.sim.data.body_xpos[temp_b_ID] = new_pos
        self.sim.forward()
       

    def _get_block_init_pos(self):
        b_id=self.model.body_name2id("T_block")
        return self.model.body_pos[b_id]
    

    def step(self, action):

        temp_ee_pos=self._get_ee_pos()
        temp_ee_pos+=action
        print("action: " , action)
        # Apply action
        #self.sim.data.set_mocap_pos[:] = temp_ee_pos
        temp_ee_pos[0] = np.clip(temp_ee_pos[0],-0.1, 1)
        temp_ee_pos[1] = np.clip(temp_ee_pos[1], -1, 1)
        temp_ee_pos[2] = np.clip(temp_ee_pos[2], 1, 1.5)
        self.sim.data.set_mocap_pos("mocap", temp_ee_pos)
        
        if self.render_enabled and self.viewer is not None:
            self.render()
        
        for _ in range(5):  # sub-steps
            self.sim.step()
        



        reward, collision = self._calculate_reward()
        return self._get_obs(), reward, collision, {}

    def render(self, mode="human"):
        self.viewer.render()

    def _set_ee_pos(self, new_pos):
        """設定末端 (mocap) 的位置"""
        self.sim.data.set_mocap_pos("mocap", new_pos)
        self.sim.forward()    


    def _get_obs(self):
        # Return observation (robot state + object position + goal position)
        ee_pos = self._get_ee_pos()
        block_pos = self._get_block_pos()
        return np.concatenate([
            ee_pos,
           block_pos
        ]).astype(np.float32)

    def _calculate_reward(self):
        #(phase 0:reaching, phase 1 :Push)
        # Calculate distance between object and goal
        collision = False
        object_pos = self._get_ee_pos()
        #block_init_pos=np.array([1, -0.2, 1.2])
        goal_pos = self.block_init_pos+np.array([0, 0, 0.0])#
        #print("goal_pos",goal_pos)
        dist = np.linalg.norm(object_pos - goal_pos)
        reach_reward = 1-np.tanh(10*dist)
        if self.phase==0:
          
            reward=0.6*reach_reward
            if dist < 0.05:
              self.phase=1
              # Success condition
            #print("block_init_pos",self.block_init_pos,"block_cur_pos",self._get_block_pos())
            flag=np.allclose(self._get_block_pos(), self.block_init_pos, atol=1e-3)
            print("flag",flag)
            if not np.allclose(self._get_block_pos(), self.block_init_pos,atol=1e-3):
                print("phase=0")
                collision = True
                #print("Block position",self._get_block_pos(),"Block_init",self.block_init_pos)
            if collision == True:    
                reward-=3

        return reward, collision

